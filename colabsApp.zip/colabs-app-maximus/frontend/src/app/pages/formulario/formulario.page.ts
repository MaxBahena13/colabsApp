﻿import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import {
  IonContent, IonHeader, IonTitle, IonToolbar, IonButtons, IonBackButton, IonInput,
  IonSelect, IonSelectOption, IonButton, IonCard, IonCardHeader, IonCardTitle, IonCardContent, IonNote
} from '@ionic/angular';

@Component({
  selector: 'app-formulario',
  templateUrl: './formulario.page.html',
  styleUrls: ['./formulario.page.scss'],
  standalone: true,
  imports: [
    FormsModule, IonContent, IonHeader, IonTitle, IonToolbar, IonButtons, IonBackButton, IonInput,
    IonSelect, IonSelectOption, IonButton, IonCard, IonCardHeader, IonCardTitle, IonCardContent, IonNote
  ]
})
export class FormularioPage {
  usuario = { nombre: '', correo: '', rol: 'usuario', comentarios: '' };
  jsonResultado = '';
  error = '';

  generarJSON() {
    const nombre = this.usuario.nombre.trim();
    const correo = this.usuario.correo.trim();

    if (!nombre) {
      this.error = 'El nombre es obligatorio';
      this.jsonResultado = '';
      return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(correo)) {
      this.error = 'Escribe un correo válido';
      this.jsonResultado = '';
      return;
    }

    this.error = '';
    const dataObject = {
      nombre,
      correo,
      rol: this.usuario.rol,
      comentarios: this.usuario.comentarios.trim(),
      fechaCaptura: new Date().toISOString()
    };
    this.jsonResultado = JSON.stringify(dataObject, null, 2);
  }
}
