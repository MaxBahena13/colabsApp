﻿import { Component, ChangeDetectorRef } from '@angular/core';
import {
  IonContent, IonHeader, IonTitle, IonToolbar, IonButtons, IonBackButton, IonGrid, IonRow, IonCol,
  IonCard, IonCardHeader, IonCardTitle, IonCardSubtitle, IonCardContent, IonSpinner, IonButton,
  IonInfiniteScroll, IonInfiniteScrollContent
} from '@ionic/angular';
import axios from 'axios';

interface Personaje {
  id: number;
  name: string;
  status: string;
  species: string;
  image: string;
  origin: { name: string };
  location: { name: string };
}

const API = 'https://rickandmortyapi.com/api/character';

@Component({
  selector: 'app-rick-and-morty',
  templateUrl: './rick-and-morty.page.html',
  styleUrls: ['./rick-and-morty.page.scss'],
  standalone: true,
  imports: [
    IonContent, IonHeader, IonTitle, IonToolbar, IonButtons, IonBackButton, IonGrid, IonRow, IonCol,
    IonCard, IonCardHeader, IonCardTitle, IonCardSubtitle, IonCardContent, IonSpinner, IonButton,
    IonInfiniteScroll, IonInfiniteScrollContent
  ]
})
export class RickAndMortyPage {
  personajes: Personaje[] = [];
  cargando = true;
  error = '';
  private pagina = 1;
  private hayMas = true;

  constructor(private cdr: ChangeDetectorRef) {}

  ionViewWillEnter() {
    if (this.personajes.length === 0) this.obtenerPersonajes();
  }

  async obtenerPersonajes() {
    this.cargando = true;
    this.error = '';
    try {
      this.personajes = await this.pedirPagina(1);
      this.pagina = 1;
    } catch {
      this.error = 'No fue posible traer los personajes';
    } finally {
      this.cargando = false;
      this.cdr.detectChanges();
    }
  }

  async cargarMas(ev: any) {
    if (!this.hayMas) {
      ev.target.complete();
      return;
    }
    try {
      const nuevos = await this.pedirPagina(this.pagina + 1);
      this.personajes = [...this.personajes, ...nuevos];
      this.pagina++;
    } catch {
      this.hayMas = false;
    } finally {
      ev.target.complete();
      this.cdr.detectChanges();
    }
  }

  claseEstado(status: string) {
    return { alive: 'status-alive', dead: 'status-dead' }[status.toLowerCase()] ?? 'status-unknown';
  }

  private async pedirPagina(pagina: number): Promise<Personaje[]> {
    const { data } = await axios.get(API, { params: { page: pagina }, timeout: 10000 });
    this.hayMas = !!data.info?.next;
    return data.results;
  }
}
