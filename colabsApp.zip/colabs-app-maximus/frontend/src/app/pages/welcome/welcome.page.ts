import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
import { IonContent, IonButton, IonIcon } from '@ionic/angular';
import { addIcons } from 'ionicons';
import { people, searchOutline, personAddOutline, albumsOutline, arrowForward } from 'ionicons/icons';

@Component({
  selector: 'app-welcome',
  templateUrl: './welcome.page.html',
  styleUrls: ['./welcome.page.scss'],
  standalone: true,
  imports: [RouterLink, IonContent, IonButton, IonIcon]
})
export class WelcomePage {
  constructor() {
    addIcons({ people, searchOutline, personAddOutline, albumsOutline, arrowForward });
  }
}
