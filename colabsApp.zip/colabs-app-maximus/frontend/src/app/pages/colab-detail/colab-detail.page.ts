﻿import { Component, ChangeDetectorRef } from '@angular/core';
import { CurrencyPipe } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import {
  IonContent, IonHeader, IonTitle, IonToolbar, IonButtons, IonBackButton,
  IonButton, IonIcon, IonModal, IonSpinner, ToastController
} from '@ionic/angular';
import { addIcons } from 'ionicons';
import {
  mailOutline, cashOutline, documentTextOutline, createOutline, trashOutline, alertCircleOutline
} from 'ionicons/icons';
import { ColabService, Colaborador } from '../../services/colabs.service';

@Component({
  selector: 'app-colab-detail',
  templateUrl: './colab-detail.page.html',
  styleUrls: ['./colab-detail.page.scss'],
  standalone: true,
  imports: [
    CurrencyPipe, IonContent, IonHeader, IonTitle, IonToolbar, IonButtons,
    IonBackButton, IonButton, IonIcon, IonModal, IonSpinner
  ]
})
export class ColabDetailPage {
  colab?: Colaborador;
  cargando = true;
  error = '';
  eliminando = false;
  mostrarModalEliminar = false;
  private id = '';

  constructor(
  private route: ActivatedRoute,
  private router: Router,
  private colabService: ColabService,
  private toastCtrl: ToastController,
  private cdr: ChangeDetectorRef
) {
    addIcons({ mailOutline, cashOutline, documentTextOutline, createOutline, trashOutline, alertCircleOutline });
  }

  // ionViewWillEnter (y no ngOnInit): Ionic reutiliza la página en la pila, así se recarga tras editar
  ionViewWillEnter() {
    this.id = this.route.snapshot.queryParamMap.get('id') ?? '';
    this.cargarDetalle();
  }

  async cargarDetalle() {
    this.cargando = true;
    this.error = '';
    if (!this.id) {
      this.cargando = false;
      this.error = 'No se indicó qué colaborador mostrar.';
      this.cdr.detectChanges();
      return;
    }
    try {
      this.colab = await this.colabService.getColaboradorById(this.id);
    } catch (e) {
      this.colab = undefined;
      this.error = (e as Error).message;
    } finally {
      this.cargando = false;
      this.cdr.detectChanges();
    }
  }

  inicial() {
    return (this.colab?.strNombre || '?').charAt(0).toUpperCase();
  }

  editar() {
    if (this.colab?._id) this.router.navigate(['/colab-form'], { queryParams: { id: this.colab._id } });
  }

  abrirConfirmacionEliminar() {
    this.mostrarModalEliminar = true;
  }

  cerrarModal() {
    this.mostrarModalEliminar = false;
  }

  async confirmarEliminar() {
    if (!this.colab?._id || this.eliminando) return;
    this.eliminando = true;
    this.cdr.detectChanges();
    try {
      await this.colabService.deleteColaborador(this.colab._id);
      this.cerrarModal();
      await this.mostrarToast('Colaborador dado de baja', 'success');
      this.router.navigate(['/colabs-list'], { replaceUrl: true });
    } catch (e) {
      this.cerrarModal();
      await this.mostrarToast((e as Error).message, 'danger');
    } finally {
      this.eliminando = false;
      this.cdr.detectChanges();
    }
  }

  private async mostrarToast(message: string, color: 'success' | 'danger') {
    const toast = await this.toastCtrl.create({ message, color, duration: 2500, position: 'bottom' });
    await toast.present();
  }
}
