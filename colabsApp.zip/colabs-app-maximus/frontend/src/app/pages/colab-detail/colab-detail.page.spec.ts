﻿import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ColabDetailPage } from './colab-detail.page';

describe('ColabDetailPage', () => {
  let component: ColabDetailPage;
  let fixture: ComponentFixture<ColabDetailPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(ColabDetailPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
