﻿import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ColabsListPage } from './colabs-list.page';

describe('ColabsListPage', () => {
  let component: ColabsListPage;
  let fixture: ComponentFixture<ColabsListPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(ColabsListPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
