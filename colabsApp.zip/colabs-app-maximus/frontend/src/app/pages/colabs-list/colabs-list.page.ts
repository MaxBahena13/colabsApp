import { Component, ChangeDetectorRef } from '@angular/core';
import { Router } from '@angular/router';
import {
  IonContent, IonHeader, IonTitle, IonToolbar, IonSearchbar, IonList, IonItem,
  IonLabel, IonFab, IonIcon, IonSpinner, IonButton, IonButtons, IonBackButton
} from '@ionic/angular';
import { addIcons } from 'ionicons';
import { add, chevronForward, peopleOutline, alertCircleOutline } from 'ionicons/icons';
import { ColabService, Colaborador } from '../../services/colabs.service';

const normalizar = (t: string) =>
  (t || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');

@Component({
  selector: 'app-colabs-list',
  templateUrl: './colabs-list.page.html',
  styleUrls: ['./colabs-list.page.scss'],
  standalone: true,
  imports: [
    IonContent, IonHeader, IonTitle, IonToolbar, IonSearchbar, IonList, IonItem,
    IonLabel, IonFab, IonIcon, IonSpinner, IonButton, IonButtons, IonBackButton
  ]
})
export class ColabsListPage {
  colaboradores: Colaborador[] = [];
  colaboradoresFiltrados: Colaborador[] = [];
  cargando = true;
  error = '';
  private texto = '';

constructor(
  private colabService: ColabService,
  private router: Router,
  private cdr: ChangeDetectorRef
) {
    addIcons({ add, chevronForward, peopleOutline, alertCircleOutline });
  }

  // Se ejecuta cada vez que se entra a la pantalla (al volver de crear/editar/eliminar la lista se refresca)
  ionViewWillEnter() {
    this.cargarColaboradores();
  }

  async cargarColaboradores() {
  this.cargando = true;
  this.error = '';
  this.cdr.detectChanges();
  try {
    this.colaboradores = await this.colabService.getColaboradores();
    this.filtrar();
  } catch (e) {
    this.colaboradores = [];
    this.colaboradoresFiltrados = [];
    this.error = (e as Error).message;
  } finally {
    this.cargando = false;
    this.cdr.detectChanges();
  }
}

  buscar(event: any) {
    this.texto = normalizar(event.detail.value ?? '').trim();
    this.filtrar();
  }

  private filtrar() {
    if (!this.texto) {
      this.colaboradoresFiltrados = [...this.colaboradores];
      return;
    }
    this.colaboradoresFiltrados = this.colaboradores.filter((c) =>
      normalizar(`${c.strNombre} ${c.strApellidos} ${c.strPuesto}`).includes(this.texto)
    );
  }

  inicial(c: Colaborador) {
    return (c.strNombre || '?').charAt(0).toUpperCase();
  }

  verDetalle(colab: Colaborador) {
    if (colab._id) this.router.navigate(['/colab-detail'], { queryParams: { id: colab._id } });
  }

  agregarNuevo() {
    this.router.navigate(['/colab-form']);
  }
}
