﻿import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ColabFormPage } from './colab-form.page';

describe('ColabFormPage', () => {
  let component: ColabFormPage;
  let fixture: ComponentFixture<ColabFormPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(ColabFormPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
