﻿import { Component, inject, ChangeDetectorRef } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import {
  IonContent, IonHeader, IonTitle, IonToolbar, IonButtons, IonBackButton,
  IonInput, IonButton, IonNote, IonSpinner, ToastController
} from '@ionic/angular';
import { ColabService } from '../../services/colabs.service';

// RFC mexicano: 3-4 letras + 6 dígitos (fecha) + 3 de homoclave
const RFC_REGEX = /^[A-ZÑ&]{3,4}\d{6}[A-Z0-9]{3}$/i;

@Component({
  selector: 'app-colab-form',
  templateUrl: './colab-form.page.html',
  styleUrls: ['./colab-form.page.scss'],
  standalone: true,
  imports: [
    ReactiveFormsModule, IonContent, IonHeader, IonTitle, IonToolbar, IonButtons,
    IonBackButton, IonInput, IonButton, IonNote, IonSpinner
  ]
})
export class ColabFormPage {
  isEdit = false;
  guardando = false;
  cargando = false;
  private idColab?: string;

  private fb = inject(FormBuilder);
  private cdr = inject(ChangeDetectorRef);

  form = this.fb.nonNullable.group({
    strNombre: ['', [Validators.required, Validators.minLength(2)]],
    strApellidos: ['', Validators.required],
    strPuesto: ['', Validators.required],
    floatSueldo: [0, [Validators.required, Validators.min(0)]],
    strRFC: ['', [Validators.required, Validators.pattern(RFC_REGEX)]],
    strCorreo: ['', Validators.email]
  });

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private colabService: ColabService,
    private toastCtrl: ToastController
  ) {}

  // Cada vez que se entra se reinicia el formulario (si no, "Nuevo" se quedaba con datos de la edición anterior)
  async ionViewWillEnter() {
    this.idColab = this.route.snapshot.queryParamMap.get('id') ?? undefined;
    this.isEdit = !!this.idColab;
    this.form.reset({ strNombre: '', strApellidos: '', strPuesto: '', floatSueldo: 0, strRFC: '', strCorreo: '' });

    if (this.idColab) {
      this.cargando = true;
      try {
        const data = await this.colabService.getColaboradorById(this.idColab);
        this.form.patchValue({
          strNombre: data.strNombre,
          strApellidos: data.strApellidos,
          strPuesto: data.strPuesto,
          floatSueldo: data.floatSueldo,
          strRFC: data.strRFC,
          strCorreo: data.strCorreo ?? ''
        });
      } catch (e) {
        await this.toast((e as Error).message, 'danger');
        this.router.navigate(['/colabs-list'], { replaceUrl: true });
      } finally {
        this.cargando = false;
        this.cdr.detectChanges();
      }
    }
  }

  invalido(campo: string) {
    const c = this.form.get(campo);
    return !!c && c.invalid && (c.dirty || c.touched);
  }

  async guardar() {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      await this.toast('Revisa los campos marcados en rojo', 'danger');
      return;
    }
    const v = this.form.getRawValue();
    const payload = {
      strNombre: v.strNombre.trim(),
      strApellidos: v.strApellidos.trim(),
      strPuesto: v.strPuesto.trim(),
      floatSueldo: Number(v.floatSueldo),
      strRFC: v.strRFC.trim().toUpperCase(),
      strCorreo: v.strCorreo.trim()
    };

    this.guardando = true;
    this.cdr.detectChanges();
    try {
      if (this.isEdit && this.idColab) {
        await this.colabService.updateColaborador(this.idColab, payload);
      } else {
        await this.colabService.addColaborador(payload);
      }
      await this.toast(this.isEdit ? 'Datos actualizados' : 'Colaborador registrado', 'success');
      this.router.navigate(['/colabs-list'], { replaceUrl: true });
    } catch (e) {
      await this.toast((e as Error).message, 'danger');
    } finally {
      this.guardando = false;
      this.cdr.detectChanges();
    }
  }

  private async toast(message: string, color: 'success' | 'danger') {
    const t = await this.toastCtrl.create({ message, color, duration: 2500, position: 'bottom' });
    await t.present();
  }
}
