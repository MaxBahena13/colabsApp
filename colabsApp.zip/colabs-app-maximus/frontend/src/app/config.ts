﻿import { Capacitor } from '@capacitor/core';

// En el emulador de Android Studio, "localhost" es el propio emulador:
// la PC se ve como 10.0.2.2. En un celular físico pon la IP de tu PC (ej. 192.168.1.50).
const ANDROID_HOST = '10.0.2.2';
const API_PORT = 3000;

const host = Capacitor.getPlatform() === 'android' ? ANDROID_HOST : 'localhost';

export const API_URL = `http://${host}:${API_PORT}/api`;
