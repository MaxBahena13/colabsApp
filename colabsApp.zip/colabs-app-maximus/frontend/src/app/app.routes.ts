﻿import { Routes } from '@angular/router';

export const routes: Routes = [
  { path: '', redirectTo: 'welcome', pathMatch: 'full' },
  { path: 'welcome', loadComponent: () => import('./pages/welcome/welcome.page').then((m) => m.WelcomePage) },
  { path: 'colabs-list', loadComponent: () => import('./pages/colabs-list/colabs-list.page').then((m) => m.ColabsListPage) },
  { path: 'colab-detail', loadComponent: () => import('./pages/colab-detail/colab-detail.page').then((m) => m.ColabDetailPage) },
  { path: 'colab-form', loadComponent: () => import('./pages/colab-form/colab-form.page').then((m) => m.ColabFormPage) },
  { path: 'formulario', loadComponent: () => import('./pages/formulario/formulario.page').then((m) => m.FormularioPage) },
  { path: 'rick-and-morty', loadComponent: () => import('./pages/rick-and-morty/rick-and-morty.page').then((m) => m.RickAndMortyPage) },
  { path: '**', redirectTo: 'welcome' }
];
