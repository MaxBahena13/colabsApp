﻿import { Injectable } from '@angular/core';
import axios, { AxiosError } from 'axios';
import { API_URL } from '../config';

export interface Colaborador {
  _id?: string;
  strNombre: string;
  strApellidos: string;
  strPuesto: string;
  floatSueldo: number;
  strRFC: string;
  strCorreo?: string;
}

@Injectable({ providedIn: 'root' })
export class ColabService {
  private readonly http = axios.create({
    baseURL: `${API_URL}/colabs`,
    timeout: 10000,
    headers: { 'Content-Type': 'application/json' }
  });

  async getColaboradores(): Promise<Colaborador[]> {
    return this.run(() => this.http.get<Colaborador[]>('/'));
  }

  async getColaboradorById(id: string): Promise<Colaborador> {
    return this.run(() => this.http.get<Colaborador>(`/${id}`));
  }

  async addColaborador(colab: Colaborador): Promise<Colaborador> {
    return this.run(() => this.http.post<Colaborador>('/', this.limpiar(colab)));
  }

  async updateColaborador(id: string, colab: Partial<Colaborador>): Promise<Colaborador> {
    return this.run(() => this.http.put<Colaborador>(`/${id}`, this.limpiar(colab)));
  }

  async deleteColaborador(id: string): Promise<void> {
    await this.run(() => this.http.delete(`/${id}`));
  }

  /** Quita _id y campos de Mongo, y asegura que el sueldo viaje como número. */
  private limpiar(colab: Partial<Colaborador>) {
    const { _id, ...resto } = colab as any;
    delete resto.createdAt;
    delete resto.updatedAt;
    if (resto.floatSueldo !== undefined) resto.floatSueldo = Number(resto.floatSueldo) || 0;
    return resto;
  }

  /** Ejecuta la petición y convierte cualquier fallo en un Error con mensaje legible para el usuario. */
  private async run<T>(request: () => Promise<{ data: T }>): Promise<T> {
    try {
      return (await request()).data;
    } catch (e) {
      const err = e as AxiosError<{ message?: string }>;
      if (err.response) {
        throw new Error(err.response.data?.message || `Error del servidor (${err.response.status})`);
      }
      throw new Error('No se pudo conectar con el servidor. Revisa que la API esté encendida.');
    }
  }
}
