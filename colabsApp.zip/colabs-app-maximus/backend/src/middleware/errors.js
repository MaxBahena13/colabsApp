// Envuelve handlers async para mandar los errores al errorHandler
exports.asyncHandler = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

exports.notFound = (req, res) => {
  res.status(404).json({ message: `Ruta no encontrada: ${req.method} ${req.originalUrl}` });
};

// eslint-disable-next-line no-unused-vars
exports.errorHandler = (err, req, res, next) => {
  if (err.type === 'entity.parse.failed') {
    return res.status(400).json({ message: 'JSON inválido' });
  }
  if (err.name === 'ValidationError') {
    const errors = Object.values(err.errors).map((e) => e.message);
    return res.status(400).json({ message: errors.join(', '), errors });
  }
  if (err.name === 'CastError') {
    return res.status(400).json({ message: 'ID inválido' });
  }
  if (err.code === 11000) {
    const campo = Object.keys(err.keyPattern || {})[0] || 'campo';
    return res.status(409).json({ message: `Ya existe un registro con ese ${campo}` });
  }
  console.error(err);
  res.status(500).json({ message: 'Error interno del servidor' });
};
