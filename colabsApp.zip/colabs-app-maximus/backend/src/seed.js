// Carga colaboradores de ejemplo: npm run seed
require('dotenv').config();
const mongoose = require('mongoose');
const Colab = require('./models/Colab');

const MONGO_URI = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/colabsAppMaximus';

const datos = [
  { strNombre: 'Maximus', strApellidos: 'Bahena de Lara', strPuesto: 'Desarrollador Full Stack', floatSueldo: 38000, strRFC: 'BALM060315XY7', strCorreo: 'maximus@correo.com' },
  { strNombre: 'Sofía', strApellidos: 'Ramírez Cuevas', strPuesto: 'Diseñadora UX', floatSueldo: 32000, strRFC: 'RACS890214HT5', strCorreo: 'sofia.ramirez@correo.com' },
  { strNombre: 'Diego', strApellidos: 'Hernández Torres', strPuesto: 'Analista de datos', floatSueldo: 29500, strRFC: 'HETD870930KL2', strCorreo: 'diego.hernandez@correo.com' },
  { strNombre: 'Valeria', strApellidos: 'Núñez Ortega', strPuesto: 'Gerente de proyectos', floatSueldo: 52000, strRFC: 'NUOV950618QW9', strCorreo: 'valeria.nunez@correo.com' },
  { strNombre: 'Carlos', strApellidos: 'Mendoza Ibarra', strPuesto: 'Soporte técnico', floatSueldo: 18500, strRFC: 'MEIC800122PA4', strCorreo: '' }
];

(async () => {
  await mongoose.connect(MONGO_URI);
  for (const d of datos) await Colab.updateOne({ strRFC: d.strRFC }, d, { upsert: true, runValidators: true });
  console.log(`Listo: ${datos.length} colaboradores cargados en ${mongoose.connection.name}`);
  await mongoose.disconnect();
})().catch((e) => { console.error(e.message); process.exit(1); });
