const router = require('express').Router();
const bcrypt = require('bcryptjs');
const User = require('../models/User');
const { asyncHandler } = require('../middleware/errors');

const CAMPOS = ['strCorreo', 'strRol'];
const pick = (body = {}) => Object.fromEntries(CAMPOS.filter((c) => body[c] !== undefined).map((c) => [c, body[c]]));

async function hashear(password) {
  if (typeof password !== 'string' || password.length < 6) {
    const err = new Error('La contraseña debe tener al menos 6 caracteres');
    err.name = 'ValidationError';
    err.errors = { strPassword: { message: err.message } };
    throw err;
  }
  return bcrypt.hash(password, 10);
}

router.get('/', asyncHandler(async (req, res) => {
  res.json(await User.find().sort({ strCorreo: 1 }));
}));

router.get('/:id', asyncHandler(async (req, res) => {
  const user = await User.findById(req.params.id);
  if (!user) return res.status(404).json({ message: 'Usuario no encontrado' });
  res.json(user);
}));

router.post('/', asyncHandler(async (req, res) => {
  const strPassword = await hashear(req.body?.strPassword);
  const user = await User.create({ ...pick(req.body), strPassword });
  const { strPassword: _omit, ...seguro } = user.toObject();
  res.status(201).json(seguro);
}));

router.put('/:id', asyncHandler(async (req, res) => {
  const cambios = pick(req.body);
  if (req.body?.strPassword !== undefined) cambios.strPassword = await hashear(req.body.strPassword);
  const user = await User.findByIdAndUpdate(req.params.id, cambios, { new: true, runValidators: true });
  if (!user) return res.status(404).json({ message: 'Usuario no encontrado' });
  res.json(user);
}));

router.delete('/:id', asyncHandler(async (req, res) => {
  const user = await User.findByIdAndDelete(req.params.id);
  if (!user) return res.status(404).json({ message: 'Usuario no encontrado' });
  res.json({ message: 'Usuario eliminado' });
}));

module.exports = router;
