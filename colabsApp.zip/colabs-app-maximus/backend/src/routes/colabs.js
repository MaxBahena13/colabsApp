const router = require('express').Router();
const Colab = require('../models/Colab');
const { asyncHandler } = require('../middleware/errors');

const CAMPOS = ['strNombre', 'strApellidos', 'strPuesto', 'floatSueldo', 'strRFC', 'strCorreo'];
const pick = (body = {}) => Object.fromEntries(CAMPOS.filter((c) => body[c] !== undefined).map((c) => [c, body[c]]));

router.get('/', asyncHandler(async (req, res) => {
  res.json(await Colab.find().sort({ strNombre: 1, strApellidos: 1 }));
}));

router.get('/:id', asyncHandler(async (req, res) => {
  const colab = await Colab.findById(req.params.id);
  if (!colab) return res.status(404).json({ message: 'Colaborador no encontrado' });
  res.json(colab);
}));

router.post('/', asyncHandler(async (req, res) => {
  const colab = await Colab.create(pick(req.body));
  res.status(201).json(colab);
}));

router.put('/:id', asyncHandler(async (req, res) => {
  const colab = await Colab.findByIdAndUpdate(req.params.id, pick(req.body), { new: true, runValidators: true });
  if (!colab) return res.status(404).json({ message: 'Colaborador no encontrado' });
  res.json(colab);
}));

router.delete('/:id', asyncHandler(async (req, res) => {
  const colab = await Colab.findByIdAndDelete(req.params.id);
  if (!colab) return res.status(404).json({ message: 'Colaborador no encontrado' });
  res.json({ message: 'Colaborador dado de baja' });
}));

module.exports = router;
