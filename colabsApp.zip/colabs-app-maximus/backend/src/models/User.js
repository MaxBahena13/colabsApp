const mongoose = require('mongoose');

const userSchema = new mongoose.Schema(
  {
    strCorreo: {
      type: String,
      required: [true, 'El correo es obligatorio'],
      trim: true,
      lowercase: true,
      unique: true,
      match: [/^[^\s@]+@[^\s@]+\.[^\s@]+$/, 'El correo no es válido']
    },
    // select:false => nunca sale en las consultas a menos que se pida explícitamente
    strPassword: { type: String, required: [true, 'La contraseña es obligatoria'], select: false },
    strRol: { type: String, enum: ['usuario', 'colaborador', 'administrador'], default: 'usuario' }
  },
  { timestamps: true, versionKey: false }
);

// Misma colección que usaba la versión anterior (clUsuarios)
module.exports = mongoose.model('User', userSchema, 'clUsuarios');
