const mongoose = require('mongoose');

const RFC_REGEX = /^[A-ZÑ&]{3,4}\d{6}[A-Z0-9]{3}$/;

const colabSchema = new mongoose.Schema(
  {
    strNombre: { type: String, required: [true, 'El nombre es obligatorio'], trim: true, minlength: [2, 'El nombre es muy corto'] },
    strApellidos: { type: String, required: [true, 'Los apellidos son obligatorios'], trim: true },
    strPuesto: { type: String, required: [true, 'El puesto es obligatorio'], trim: true },
    floatSueldo: { type: Number, required: [true, 'El sueldo es obligatorio'], min: [0, 'El sueldo no puede ser negativo'] },
    strRFC: {
      type: String,
      required: [true, 'El RFC es obligatorio'],
      trim: true,
      uppercase: true,
      unique: true,
      match: [RFC_REGEX, 'El RFC no tiene un formato válido']
    },
    strCorreo: {
      type: String,
      trim: true,
      lowercase: true,
      default: '',
      match: [/^$|^[^\s@]+@[^\s@]+\.[^\s@]+$/, 'El correo no es válido']
    }
  },
  { timestamps: true, versionKey: false }
);

// Misma colección que usaba la versión anterior (clColabs)
module.exports = mongoose.model('Colab', colabSchema, 'clColabs');
