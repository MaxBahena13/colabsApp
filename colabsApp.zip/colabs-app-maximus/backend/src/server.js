require('dotenv').config();
const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
const { notFound, errorHandler } = require('./middleware/errors');

const PORT = process.env.PORT || 3000;
const MONGO_URI = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/colabsAppMaximus';

const app = express();
app.use(cors()); // la app Ionic/Android hace las peticiones desde otro origen
app.use(express.json());

app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', db: mongoose.connection.readyState === 1 ? 'conectada' : 'desconectada' });
});
app.use('/api/colabs', require('./routes/colabs'));
app.use('/api/users', require('./routes/users'));

app.use(notFound);
app.use(errorHandler);

async function start() {
  try {
    await mongoose.connect(MONGO_URI);
    console.log('MongoDB conectado:', mongoose.connection.name);
    // 0.0.0.0 para que el emulador (10.0.2.2) y el celular por WiFi puedan entrar
    app.listen(PORT, '0.0.0.0', () => console.log(`API lista en http://localhost:${PORT}/api`));
  } catch (err) {
    console.error('No se pudo conectar a MongoDB:', err.message);
    process.exit(1);
  }
}
start();
